class DummyHashAnnouncer(object):
    def __init__(self, *args):
        pass

    def run_manage_loop(self):
        pass

    def stop(self):
        pass

    def add_supplier(self, *args):
        pass

    def immediate_announce(self, *args):
        pass